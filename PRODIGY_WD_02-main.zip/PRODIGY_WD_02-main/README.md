# prodigy_wd_02
This code is for the submission of Task 2 for Prodigy InfoTech Internship. I have created a Simple Stopwatch with reset, pause, start and lap time button.

